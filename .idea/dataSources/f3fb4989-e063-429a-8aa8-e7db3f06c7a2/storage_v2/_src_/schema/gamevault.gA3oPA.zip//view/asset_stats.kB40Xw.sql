create definer = root@localhost view asset_stats as
select `a`.`id`             AS `id`,
       `a`.`name`           AS `name`,
       `a`.`file_type`      AS `file_type`,
       `a`.`category`       AS `category`,
       `a`.`status`         AS `status`,
       `a`.`file_size`      AS `file_size`,
       `a`.`download_count` AS `download_count`,
       `a`.`view_count`     AS `view_count`,
       `u`.`username`       AS `uploader_name`,
       `p`.`name`           AS `project_name`,
       `a`.`created_at`     AS `created_at`
from ((`gamevault`.`assets` `a` left join `gamevault`.`users` `u`
       on ((`a`.`uploader_id` = `u`.`id`))) left join `gamevault`.`projects` `p` on ((`a`.`project_id` = `p`.`id`)));

-- comment on column asset_stats.id not supported: 资产ID

-- comment on column asset_stats.name not supported: 资产名称

-- comment on column asset_stats.file_type not supported: 文件类型

-- comment on column asset_stats.category not supported: 资产分类

-- comment on column asset_stats.status not supported: 审核状态

-- comment on column asset_stats.file_size not supported: 文件大小(字节)

-- comment on column asset_stats.download_count not supported: 下载次数

-- comment on column asset_stats.view_count not supported: 查看次数

-- comment on column asset_stats.uploader_name not supported: 用户名

-- comment on column asset_stats.project_name not supported: 项目名称

-- comment on column asset_stats.created_at not supported: 创建时间

