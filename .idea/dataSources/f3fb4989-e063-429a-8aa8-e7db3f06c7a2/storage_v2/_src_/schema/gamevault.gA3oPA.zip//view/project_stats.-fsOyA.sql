create definer = root@localhost view project_stats as
select `p`.`id`                       AS `id`,
       `p`.`name`                     AS `name`,
       `p`.`type`                     AS `type`,
       `p`.`status`                   AS `status`,
       `p`.`progress`                 AS `progress`,
       `u`.`username`                 AS `owner_name`,
       count(distinct `a`.`id`)       AS `asset_count`,
       count(distinct `pm`.`user_id`) AS `member_count`,
       `p`.`created_at`               AS `created_at`,
       `p`.`updated_at`               AS `updated_at`
from (((`gamevault`.`projects` `p` left join `gamevault`.`users` `u`
        on ((`p`.`owner_id` = `u`.`id`))) left join `gamevault`.`assets` `a`
       on ((`p`.`id` = `a`.`project_id`))) left join `gamevault`.`project_members` `pm`
      on ((`p`.`id` = `pm`.`project_id`)))
group by `p`.`id`;

-- comment on column project_stats.id not supported: 项目ID

-- comment on column project_stats.name not supported: 项目名称

-- comment on column project_stats.type not supported: 项目类型

-- comment on column project_stats.status not supported: 项目状态

-- comment on column project_stats.progress not supported: 项目进度(0-100)

-- comment on column project_stats.owner_name not supported: 用户名

-- comment on column project_stats.created_at not supported: 创建时间

-- comment on column project_stats.updated_at not supported: 更新时间

