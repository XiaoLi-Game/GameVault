create
    definer = root@localhost procedure CleanupExpiredData()
BEGIN
    -- 清理过期会话
    DELETE FROM user_sessions WHERE expires_at < NOW();

    -- 清理30天前的调试日志
    DELETE FROM system_logs WHERE level = 'debug' AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);

    -- 清理90天前的信息日志
    DELETE FROM system_logs WHERE level = 'info' AND created_at < DATE_SUB(NOW(), INTERVAL 90 DAY);

    -- 更新文件引用计数
    UPDATE file_storage fs
    SET reference_count = (
        SELECT COUNT(*) FROM assets a WHERE a.file_hash = fs.file_hash
    );

    -- 删除无引用的文件记录
    DELETE FROM file_storage WHERE reference_count = 0;
END;

