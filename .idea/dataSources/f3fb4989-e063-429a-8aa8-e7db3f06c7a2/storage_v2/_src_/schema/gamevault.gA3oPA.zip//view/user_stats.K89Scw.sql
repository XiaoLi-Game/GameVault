create definer = root@localhost view user_stats as
select `u`.`id`                 AS `id`,
       `u`.`username`           AS `username`,
       `u`.`email`              AS `email`,
       `u`.`role`               AS `role`,
       count(distinct `p`.`id`) AS `project_count`,
       count(distinct `a`.`id`) AS `asset_count`,
       `u`.`login_count`        AS `login_count`,
       `u`.`last_login_at`      AS `last_login_at`,
       `u`.`created_at`         AS `created_at`
from ((`gamevault`.`users` `u` left join `gamevault`.`projects` `p`
       on ((`u`.`id` = `p`.`owner_id`))) left join `gamevault`.`assets` `a` on ((`u`.`id` = `a`.`uploader_id`)))
group by `u`.`id`;

-- comment on column user_stats.id not supported: 用户ID

-- comment on column user_stats.username not supported: 用户名

-- comment on column user_stats.email not supported: 邮箱

-- comment on column user_stats.role not supported: 用户角色

-- comment on column user_stats.login_count not supported: 登录次数

-- comment on column user_stats.last_login_at not supported: 最后登录时间

-- comment on column user_stats.created_at not supported: 创建时间

