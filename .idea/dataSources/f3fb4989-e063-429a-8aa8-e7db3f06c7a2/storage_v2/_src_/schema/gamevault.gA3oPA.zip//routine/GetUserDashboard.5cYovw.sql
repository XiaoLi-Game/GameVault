create
    definer = root@localhost procedure GetUserDashboard(IN user_id int)
BEGIN
    -- 用户基本信息
    SELECT username, email, role, avatar, last_login_at FROM users WHERE id = user_id;

    -- 用户项目统计
    SELECT
        COUNT(*) as total_projects,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_projects,
        SUM(CASE WHEN status = 'development' THEN 1 ELSE 0 END) as active_projects
    FROM projects WHERE owner_id = user_id;

    -- 用户资产统计
    SELECT
        COUNT(*) as total_assets,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_assets,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_assets
    FROM assets WHERE uploader_id = user_id;

    -- 最近活动
    SELECT 'asset' as type, name, created_at FROM assets WHERE uploader_id = user_id
    UNION ALL
    SELECT 'project' as type, name, created_at FROM projects WHERE owner_id = user_id
    ORDER BY created_at DESC LIMIT 10;
END;

